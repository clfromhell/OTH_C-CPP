#include <stdio.h>

char *strcpy(char *dest, const char *src);

int main() {
    char txt1[100] = "Ha";
    char txt2[] = "WELT!";

    strcpy(txt1, txt2);
    printf("%s", txt1);
    printf("%s", txt2);

    return 0;
}

char *strcpy(char *dest, const char *src){

    char *result = dest;

    while(*src != '\0'){
        *dest = *src;
        dest++;
        src++;
    }

    if(*dest != '\0'){
        while(*dest != '\0'){
            *dest = NULL;
            dest++;
        }
    }

    return result;
}