#include <stdio.h>

char *memcpy(void *dest, const void *src, size_t n){

    void *result = dest;

    int i;
    for(i = 0; i < n; i++){
        *(char*)dest = *(char*)src;
        dest++;
        src++;
    }

    return result;

}

int main() {
    char a[100] = "Hallo";
    char b[100] = "Servus";

    printf("%s \n", a);

    memcpy(a, b, 6);

    printf("%s", a);
    return 0;
}