#include <stdio.h>

char *strcat(char *dest, const char *src);

int main() {

    char txt1[100] = "Hallo";
    char txt2[] = "WELT!";

    strcat(txt1, txt2);
    printf("%s", txt1);

    return 0;
}

char *strcat(char *dest, const char *src){

    char *result = dest;

    while(*dest != '\0'){
        dest++;
    }

    char current;
    do{
        current = *src;
        *dest = *src;
        dest++;
        src++;
    }while(current != '\0');

    return result;
}