#include <stdio.h>
#include <mem.h>

void *memset(void *ptr, int value, size_t n){
    ptr++;
    int i;
    for(i = 0; i < n; i++){
        *(char*)ptr = value;
        ptr++;
    }
}

int main() {

    char a[] = "Oh fuck";
    char *ptr = strchr(a, 'f'); //suche nach f; setze ptr auf adresse von f

    printf("%s \n", a);
    memset(ptr, '*', 3);
    printf("%s", a);

    return 0;
}

//vgl: http://openbook.rheinwerk-verlag.de/c_von_a_bis_z/020_c_headerdateien_008.htm
//leicht anders, denn ptr wird nicht in memset sondern davor um 1 erhöht