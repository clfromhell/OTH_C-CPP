#include <stdio.h>

int strcmp(char[], char[], int);


int main() {

    char string1[100];
    char string2[100];
    int len = 0;

    printf("Laenge eingeben");
    scanf("%d", &len);

    printf("String 1 eingeben:");
    scanf("%s", string1);

    printf("sTRING 2 EINGBEN");
    scanf("%s", string2);

    if(strcmp(string1, string2, len) == 0){
        printf("Sind gleich.");
    }else{
        printf("ungleich");
    }

    return 0;
}

int strcmp(char str1[100], char str2[100], int len){

    for(int i = 0; i < len; i++){
        if(str1[i] != str2[i]) {
            return 1;
        }
    }
    return 0;

}